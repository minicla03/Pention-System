# -*- coding: utf-8 -*-
"""
Created on Tue Sep 20 17:29:20 2022

@author: sweel
"""
from tensorflow.keras.models import Sequential
from tensorflow.keras import layers
from tensorflow import keras

class_no = 7

#%% CNN Model

def CNN_Model(class_no):
    
    model = Sequential(name = 'cnn')
    model.add(keras.Input(shape=(600, 1)))

    model.add(layers.Conv1D(16, (3), activation='relu', padding='valid')) #16, 3 step
    model.add(layers.MaxPooling1D()) 
    model.add(layers.BatchNormalization())

    model.add(layers.Conv1D(32, (3), activation='relu', padding='valid'))
    model.add(layers.MaxPooling1D()) 
    model.add(layers.BatchNormalization())  
    
    model.add(layers.Conv1D(64, (3), activation='relu', padding='valid'))
    model.add(layers.AveragePooling1D()) 
    model.add(layers.BatchNormalization())
    
    model.add(layers.Flatten())

    model.add(layers.Dense(480,activation='relu'))
    model.add(layers.Dropout(0.2))
    model.add(layers.Dense(48,activation='relu'))
    model.add(layers.Dropout(0.2))

    model.add(layers.Dense(class_no, activation='softmax'))
    
    return model

#%% DNN Model

def DNN_Model(class_no):

    model = keras.Sequential(name = 'dnn')
    model.add(keras.Input(shape=(600,)))
    model.add(layers.Dense(300, activation = 'relu'))
    model.add(layers.Dropout(0.2))
    model.add(layers.Dense(30, activation = 'relu'))
    model.add(layers.Dropout(0.2))
    model.add(layers.Dense(class_no, activation = 'softmax'))
    
    return model

#%% Balanced Random Forest Classifier Model

from imblearn.ensemble import BalancedRandomForestClassifier

best = BalancedRandomForestClassifier(criterion = 'gini', max_depth =  50, 
                                      max_features = 0.1,
                                      n_estimators=1000, random_state= 36,
                                      n_jobs=-1, oob_score=True,)